package com.work.paperExtractor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaperExtractorApplicationTests {

	@Test
	void contextLoads() {
	}

}
